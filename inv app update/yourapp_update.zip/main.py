from tkinter import *
from tkinter import ttk, messagebox, simpledialog
import pandas as pd
import os
import sys
import sqlite3
import qrcode
import win32print
import win32ui
from PIL import Image, ImageWin
import matplotlib.pyplot as plt
import subprocess
from utils import (
    load_inventory, save_inventory, log_action, load_suppliers, save_suppliers, 
    load_pallets, save_pallets, load_deleted_products, save_deleted_products
)
from config import initialize_database
from database import create_tables, get_db_connection

def resource_path(relative_path):
    """ Get the absolute path to the resource, works for dev and for PyInstaller """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Auto-update check
def check_for_updates():
    updater_script = resource_path('updater.py')
    print("Checking for updates...")  # Added print statement
    result = subprocess.run(['python', updater_script], capture_output=True, text=True)
    print(result.stdout)  # Added print statement to show output of updater script
    if "Update installed successfully" in result.stdout:
        messagebox.showinfo("Update", "Update installed successfully. Please restart the application.")
        sys.exit()

# Initialize database
initialize_database()

# Ensure all paths use resource_path
db_path = resource_path('inventory.db')

def main():
    # Check for updates
    check_for_updates()
    
    # Initialize database and create tables if they do not exist
    create_tables()

    # Start the main application
    main_app("default_user", "admin")

class AddProductDialog(simpledialog.Dialog):
    def body(self, master):
        suppliers = load_suppliers()
        if suppliers.empty:
            suppliers = pd.DataFrame(columns=['Name'])
        suppliers_list = suppliers['Name'].tolist()

        self.name_var = StringVar()
        self.barcode_var = StringVar()
        self.shelf_var = StringVar()
        self.quantity_var = IntVar()
        self.threshold_var = IntVar()
        self.supplier_var = StringVar()
        self.type_var = StringVar()
        self.category_var = StringVar()

        fields = [
            ("Name:", self.name_var),
            ("Barcode:", self.barcode_var),
            ("Shelf:", self.shelf_var),
            ("Quantity:", self.quantity_var),
            ("Threshold:", self.threshold_var),
            ("Supplier:", self.supplier_var, ttk.Combobox(master, textvariable=self.supplier_var, values=suppliers_list)),
            ("Type:", self.type_var),
            ("Category:", self.category_var)
        ]

        for i, (label, var, *widget) in enumerate(fields):
            Label(master, text=label).grid(row=i, column=0)
            entry = widget[0] if widget else Entry(master, textvariable=var)
            entry.grid(row=i, column=1)

    def apply(self):
        self.result = {
            'Name': self.name_var.get(),
            'Barcode': self.barcode_var.get(),
            'Shelf': self.shelf_var.get(),
            'Quantity': self.quantity_var.get(),
            'Threshold': self.threshold_var.get(),
            'Supplier': self.supplier_var.get(),
            'Type': self.type_var.get(),
            'Category': self.category_var.get(),
        }

class AddSupplierDialog(simpledialog.Dialog):
    def body(self, master):
        Label(master, text="Supplier Name:").grid(row=0)
        self.supplier_name_var = StringVar()
        Entry(master, textvariable=self.supplier_name_var).grid(row=0, column=1)

    def apply(self):
        self.result = self.supplier_name_var.get()

class AddPalletDialog(simpledialog.Dialog):
    def body(self, master):
        self.pallet_id_var = StringVar()
        self.name_var = StringVar()
        self.barcode_var = StringVar()
        self.shelf_var = StringVar()

        fields = [
            ("Pallet ID:", self.pallet_id_var),
            ("Name:", self.name_var),
            ("Barcode:", self.barcode_var),
            ("Shelf:", self.shelf_var),
        ]

        for i, (label, var) in enumerate(fields):
            Label(master, text=label).grid(row=i, column=0)
            Entry(master, textvariable=var).grid(row=i, column=1)

    def apply(self):
        self.result = {
            'PalletID': self.pallet_id_var.get(),
            'Name': self.name_var.get(),
            'Barcode': self.barcode_var.get(),
            'Shelf': self.shelf_var.get(),
        }

def add_product(current_user, refresh_inventory, update_status):
    try:
        dialog = AddProductDialog(None, title="Add Product")
        if dialog.result:
            df = load_inventory()
            new_product = pd.DataFrame([dialog.result])
            df = pd.concat([df, new_product], ignore_index=True)
            save_inventory(df)
            log_action(current_user, "Add Product", f"Added product {dialog.result['Name']}")
            refresh_inventory()
            update_status("Product added successfully.")
    except Exception as e:
        messagebox.showerror("Add Product", f"Error adding product: {str(e)}")

def remove_product(tree, current_user, refresh_inventory, update_status):
    try:
        selected_item = tree.selection()
        if selected_item:
            df = load_inventory()
            for item in selected_item:
                product = tree.item(item)["values"]
                barcode_to_remove = str(product[1])
                df = df[df['Barcode'] != barcode_to_remove]
            save_inventory(df)
            log_action(current_user, "Remove Product", f"Removed product {product[0]}")
            refresh_inventory()
            update_status("Product removed successfully.")
        else:
            update_status("No product selected.")
    except Exception as e:
        messagebox.showerror("Remove Product", f"Error removing product: {str(e)}")

def add_pallet(current_user, refresh_pallets, update_status):
    try:
        dialog = AddPalletDialog(None, title="Add Pallet")
        if dialog.result:
            df = load_pallets()
            new_pallet = pd.DataFrame([dialog.result])
            df = pd.concat([df, new_pallet], ignore_index=True)
            save_pallets(df)
            log_action(current_user, "Add Pallet", f"Added pallet {dialog.result['PalletID']}")
            refresh_pallets()
            update_status("Pallet added successfully.")
    except Exception as e:
        messagebox.showerror("Add Pallet", f"Error adding pallet: {str(e)}")

def remove_pallet(tree, current_user, refresh_pallets, update_status):
    try:
        selected_item = tree.selection()
        if selected_item:
            df = load_pallets()
            for item in selected_item:
                pallet = tree.item(item)["values"]
                df = df[df['PalletID'] != pallet[0]]
            save_pallets(df)
            log_action(current_user, "Remove Pallet", f"Removed pallet {pallet[0]}")
            refresh_pallets()
            update_status("Pallet removed successfully.")
        else:
            update_status("No pallet selected.")
    except Exception as e:
        messagebox.showerror("Remove Pallet", f"Error removing pallet: {str(e)}")

def generate_qr_code(tree, current_user):
    selected_item = tree.selection()
    if not selected_item:
        messagebox.showerror("Generate QR Code", "No product selected.")
        return

    item_data = tree.item(selected_item[0], 'values')
    name = item_data[0]
    barcode_value = item_data[1]
    supplier = item_data[5]
    product_type = item_data[6]

    if not name or not barcode_value:
        messagebox.showerror("Generate QR Code", "Product name or barcode is missing.")
        return

    try:
        qr_data = f"Name: {name}\nBarcode: {barcode_value}\nSupplier: {supplier}\nType: {product_type}"
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        img = qr.make_image(fill='black', back_color='white')
        filename = resource_path(f"{name}_qrcode.png")
        img.save(filename)

        save_or_print = messagebox.askyesno("Generate QR Code", "Do you want to print the QR code?")

        if save_or_print:
            print_to_windows_printer(filename)
        else:
            messagebox.showinfo("Generate QR Code", f"QR code generated and saved as {filename}")

        log_action(current_user, "Generate QR Code", f"Generated QR code for {name} with barcode {barcode_value}")
    except Exception as e:
        messagebox.showerror("Generate QR Code", f"Error generating QR code: {str(e)}")

def print_to_windows_printer(filename):
    try:
        printer_name = win32print.GetDefaultPrinter()
        print_dialog = win32ui.CreateDC()
        print_dialog.CreatePrinterDC(printer_name)

        image = Image.open(filename)
        image = image.convert("RGB")
        width, height = image.size
        hdc = print_dialog.GetHandleOutput()

        print_dialog.StartDoc("Print job")
        print_dialog.StartPage()

        dib = ImageWin.Dib(image)
        dib.draw(hdc, (0, 0, width, height))

        print_dialog.EndPage()
        print_dialog.EndDoc()

        messagebox.showinfo("Print to Windows Printer", "Printing to Windows printer completed successfully.")
    except Exception as e:
        messagebox.showerror("Print to Windows Printer", f"Error printing to Windows printer: {str(e)}")

def generate_order_slip():
    try:
        df = load_inventory()
        below_threshold_df = df[df['Quantity'] < df['Threshold']]
        if below_threshold_df.empty:
            messagebox.showinfo("Generate Order Slip", "No items below threshold to generate order slip.")
            return
        order_slip_file = resource_path('order_slip.xlsx')
        below_threshold_df.to_excel(order_slip_file, index=False)
        messagebox.showinfo("Generate Order Slip", f"Order slip generated and saved as {order_slip_file}")
    except Exception as e:
        messagebox.showerror("Generate Order Slip", f"Error generating order slip: {str(e)}")

def generate_stock_report(report_type, sort_order):
    try:
        df = load_inventory()
        if df.empty:
            messagebox.showinfo("Generate Stock Report", "No inventory data available to generate report.")
            return
        stock_report_file = resource_path(f'stock_report_{report_type}.xlsx')
        df.to_excel(stock_report_file, index=False)
        messagebox.showinfo("Generate Stock Report", f"Stock report generated and saved as {stock_report_file}")
    except Exception as e:
        messagebox.showerror("Generate Stock Report", f"Error generating stock report: {str(e)}")

def visualize_stock_levels():
    try:
        df = load_inventory()
        if df.empty:
            messagebox.showinfo("Visualize Stock Levels", "No inventory data available to visualize.")
            return

        categories = df['Category'].unique()
        stock_levels = [df[df['Category'] == category]['Quantity'].sum() for category in categories]

        plt.figure(figsize=(10, 6))
        plt.bar(categories, stock_levels)
        plt.xlabel('Category')
        plt.ylabel('Stock Level')
        plt.title('Stock Levels by Category')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
    except Exception as e:
        messagebox.showerror("Visualize Stock Levels", f"Error visualizing stock levels: {str(e)}")

def generate_removed_report():
    try:
        df = load_deleted_products()
        if df.empty:
            messagebox.showinfo("Removed Product Report", "No removed product data available to generate report.")
            return
        removed_report_file = resource_path('removed_report.xlsx')
        df.to_excel(removed_report_file, index=False)
        messagebox.showinfo("Removed Product Report", f"Removed product report generated and saved as {removed_report_file}")
    except Exception as e:
        messagebox.showerror("Removed Product Report", f"Error generating removed product report: {str(e)}")

def pallet_screen(current_user, refresh_inventory, update_status):
    def refresh_pallets():
        df = load_pallets()
        update_pallet_list(df, pallet_tree)

    try:
        root = Toplevel()
        root.title("Pallet Management")
        root.geometry("800x600")
        root.minsize(600, 400)

        main_frame = Frame(root, bg='white')
        main_frame.pack(fill=BOTH, expand=True)

        search_frame = Frame(main_frame, bg='white')
        search_frame.pack(fill=X, padx=10, pady=10)

        Label(search_frame, text="Pallet ID:", bg='white').grid(row=0, column=0, padx=5, pady=5, sticky="w")
        pallet_id_var = StringVar()
        Entry(search_frame, textvariable=pallet_id_var, font=('Helvetica', 10)).grid(row=0, column=1, padx=5, pady=5, sticky="w")

        Label(search_frame, text="Name:", bg='white').grid(row=0, column=2, padx=5, pady=5, sticky="w")
        name_var = StringVar()
        Entry(search_frame, textvariable=name_var, font=('Helvetica', 10)).grid(row=0, column=3, padx=5, pady=5, sticky="w")

        search_button = Button(search_frame, text="Search", command=lambda: search_pallets(pallet_id_var.get(), name_var.get(), pallet_tree))
        search_button.grid(row=0, column=4, padx=5, pady=5, sticky="w")

        columns = ('PalletID', 'Name', 'Barcode', 'Shelf')
        pallet_tree = ttk.Treeview(main_frame, columns=columns, show='headings')
        for col in columns:
            pallet_tree.heading(col, text=col, command=lambda _col=col: sort_column(pallet_tree, _col, False))
        pallet_tree.pack(fill=BOTH, expand=True, padx=10, pady=10)

        scrollbar = ttk.Scrollbar(main_frame, orient=VERTICAL, command=pallet_tree.yview)
        pallet_tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=RIGHT, fill=Y)

        button_frame = Frame(main_frame, bg='white')
        button_frame.pack(fill=X, padx=10, pady=10)

        button_frame.columnconfigure((0, 1, 2, 3), weight=1)

        add_pallet_button = Button(button_frame, text="Add Pallet", command=lambda: add_pallet(current_user, refresh_pallets, update_status))
        add_pallet_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        remove_pallet_button = Button(button_frame, text="Remove Pallet", command=lambda: remove_pallet(pallet_tree, current_user, refresh_pallets, update_status))
        remove_pallet_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        refresh_pallets_button = Button(button_frame, text="Refresh Pallets", command=refresh_pallets)
        refresh_pallets_button.grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        refresh_pallets()

        root.mainloop()
    except Exception as e:
        messagebox.showerror("Pallet Management", f"Error in pallet management screen: {str(e)}")

def create_main_window():
    root = Tk()
    root.title("Inventory Management System")
    root.geometry("1200x800")
    root.minsize(800, 600)

    main_frame = Frame(root, bg='white')
    main_frame.pack(fill=BOTH, expand=True)
    
    return root, main_frame

def create_tabs(main_frame):
    style = ttk.Style()
    style.configure('TNotebook.Tab', font=('Helvetica', '12', 'bold'))
    style.configure('TLabel', background='white')
    style.configure('TButton', font=('Helvetica', '10', 'bold'), padding=6)
    style.configure('TEntry', font=('Helvetica', '10'))
    style.configure('Treeview.Heading', font=('Helvetica', '10', 'bold'))

    tab_control = ttk.Notebook(main_frame)
    tab1 = ttk.Frame(tab_control)
    tab2 = ttk.Frame(tab_control)
    tab_control.add(tab1, text='Inventory')
    tab_control.add(tab2, text='Administration')
    tab_control.pack(expand=1, fill='both')
    
    return tab_control, tab1, tab2

def create_inventory_tab(tab1, current_user, refresh_inventory, update_status):
    tab1.columnconfigure(0, weight=1)
    tab1.rowconfigure(1, weight=1)

    search_frame = Frame(tab1, bg='white')
    search_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

    Label(search_frame, text="Name:", bg='white').grid(row=0, column=0, padx=5, pady=5, sticky="w")
    name_var = StringVar()
    Entry(search_frame, textvariable=name_var, font=('Helvetica', 10)).grid(row=0, column=1, padx=5, pady=5, sticky="w")

    Label(search_frame, text="Barcode:", bg='white').grid(row=0, column=2, padx=5, pady=5, sticky="w")
    barcode_var = StringVar()
    Entry(search_frame, textvariable=barcode_var, font=('Helvetica', 10)).grid(row=0, column=3, padx=5, pady=5, sticky="w")

    search_button = Button(search_frame, text="Search", command=lambda: search_products(name_var.get(), barcode_var.get(), inventory_tree))
    search_button.grid(row=0, column=4, padx=5, pady=5, sticky="w")

    columns = ('Name', 'Barcode', 'Shelf', 'Quantity', 'Threshold', 'Supplier', 'Type', 'Category')
    inventory_tree = ttk.Treeview(tab1, columns=columns, show='headings')
    for col in columns:
        inventory_tree.heading(col, text=col, command=lambda _col=col: sort_column(inventory_tree, _col, False))
    inventory_tree.grid(row=1, column=0, columnspan=5, padx=10, pady=10, sticky="nsew")

    scrollbar = ttk.Scrollbar(tab1, orient=VERTICAL, command=inventory_tree.yview)
    inventory_tree.configure(yscroll=scrollbar.set)
    scrollbar.grid(row=1, column=5, sticky='ns')

    button_frame = Frame(tab1, bg='white')
    button_frame.grid(row=2, column=0, columnspan=5, padx=10, pady=10, sticky="ew")

    button_frame.columnconfigure((0, 1, 2, 3, 4, 5, 6, 7, 8), weight=1)

    buttons = [
        ("Add Product", lambda: add_product(current_user, refresh_inventory, update_status)),
        ("Remove Product", lambda: remove_product(inventory_tree, current_user, refresh_inventory, update_status)),
        ("Generate QR Code", lambda: generate_qr_code(inventory_tree, current_user)),
        ("Generate Stock Report", lambda: generate_stock_report('summary', 'asc')),
        ("Visualize Stock Levels", visualize_stock_levels),
        ("Removed Product Report", generate_removed_report),
        ("Generate Order Slip", generate_order_slip),
        ("Pallet Management", lambda: pallet_screen(current_user, refresh_inventory, update_status))
    ]

    for i, (text, command) in enumerate(buttons):
        button = Button(button_frame, text=text, command=command)
        button.grid(row=0, column=i, padx=5, pady=5, sticky="ew")

    check_stock_level(inventory_tree)

    return inventory_tree, name_var, barcode_var

def create_admin_tab(tab2, current_user, update_status):
    tab2.columnconfigure(0, weight=1)
    tab2.rowconfigure(1, weight=1)

    button_frame = Frame(tab2, bg='white')
    button_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

    button_frame.columnconfigure((0, 1), weight=1)

    add_supplier_button = Button(button_frame, text="Add Supplier", command=lambda: add_supplier(current_user, update_status))
    add_supplier_button.grid(row=0, column=0, padx=5, pady=5, sticky="ew")

    select_printer_button = Button(button_frame, text="Select Printer", command=select_printer)
    select_printer_button.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

def search_products(name, barcode, inventory_tree):
    try:
        df = load_inventory()
        if name:
            df = df[df['Name'].str.contains(name, case=False, na=False)]
        if barcode:
            df = df[df['Barcode'].str.contains(barcode, case=False, na=False)]
        update_product_list(df, inventory_tree)
    except Exception as e:
        messagebox.showerror("Search Products", f"Error searching products: {str(e)}")

def search_pallets(pallet_id, name, pallet_tree):
    try:
        df = load_pallets()
        if pallet_id:
            df = df[df['PalletID'].str.contains(pallet_id, case=False, na=False)]
        if name:
            df = df[df['Name'].str.contains(name, case=False, na=False)]
        update_pallet_list(df, pallet_tree)
    except Exception as e:
        messagebox.showerror("Search Pallets", f"Error searching pallets: {str(e)}")

def update_product_list(df, inventory_tree):
    try:
        for i in inventory_tree.get_children():
            inventory_tree.delete(i)
        for index, row in df.iterrows():
            inventory_tree.insert('', 'end', iid=index, values=list(row))
    except Exception as e:
        messagebox.showerror("Update Product List", f"Error updating product list: {str(e)}")

def update_pallet_list(df, pallet_tree):
    try:
        for i in pallet_tree.get_children():
            pallet_tree.delete(i)
        for index, row in df.iterrows():
            pallet_tree.insert('', 'end', iid=index, values=list(row))
    except Exception as e:
        messagebox.showerror("Update Pallet List", f"Error updating pallet list: {str(e)}")

def sort_column(tree, col, reverse):
    try:
        l = [(tree.set(k, col), k) for k in tree.get_children('')]
        l.sort(reverse=reverse)

        for index, (val, k) in enumerate(l):
            tree.move(k, '', index)

        tree.heading(col, command=lambda: sort_column(tree, col, not reverse))
    except Exception as e:
        messagebox.showerror("Sort Column", f"Error sorting column: {str(e)}")

class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.show_tooltip)
        self.widget.bind("<Leave>", self.hide_tooltip)

    def show_tooltip(self, event):
        self.tooltip = Toplevel(self.widget)
        self.tooltip.wm_overrideredirect(True)
        self.tooltip.geometry(f"+{event.x_root + 20}+{event.y_root + 10}")
        label = Label(self.tooltip, text=self.text, background="yellow", relief="solid", borderwidth=1, padx=5, pady=5)
        label.pack()

    def hide_tooltip(self, event):
        if self.tooltip:
            self.tooltip.destroy()

def check_stock_level(tree):
    try:
        df = load_inventory()
        low_stock_items = df[df['Quantity'] < df['Threshold']]
        if not low_stock_items.empty:
            messagebox.showwarning("Low Stock Alert", f"The following items have low stock:\n{low_stock_items['Name'].to_string(index=False)}")
    except Exception as e:
        messagebox.showerror("Check Stock Level", f"Error checking stock level: {str(e)}")

def get_printers():
    printers = win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)
    return [printer[2] for printer in printers]

def select_printer():
    printers = get_printers()
    if not printers:
        messagebox.showerror("Error", "No printers found.")
        return

    def on_printer_selected(event):
        selected_printer = printer_combobox.get()
        # Update the print path or any other required actions here
        messagebox.showinfo("Printer Selected", f"Selected Printer: {selected_printer}")

    printer_window = Toplevel()
    printer_window.title("Select Printer")

    Label(printer_window, text="Select a printer:").pack(padx=10, pady=10)

    printer_combobox = ttk.Combobox(printer_window, values=printers)
    printer_combobox.pack(padx=10, pady=10)
    printer_combobox.bind("<<ComboboxSelected>>", on_printer_selected)

    printer_window.mainloop()

def main_app(username, role):
    try:
        root, main_frame = create_main_window()
        tab_control, tab1, tab2 = create_tabs(main_frame)

        def refresh_inventory():
            df = load_inventory()
            update_product_list(df, inventory_tree)

        def update_status(status):
            print(status)

        inventory_tree, name_var, barcode_var = create_inventory_tab(tab1, username, refresh_inventory, update_status)
        create_admin_tab(tab2, username, update_status)
        refresh_inventory()

        root.mainloop()
    except Exception as e:
        messagebox.showerror("Main App", f"Error in main app: {str(e)}")

print("Application started...")

if __name__ == "__main__":
    main()

